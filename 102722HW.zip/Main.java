import Instances.Crew;
public class Main {

    public static void main(String[] args) {
        Crew abrams = new Crew();
        Crew leopard = new Crew();
        Crew type10 = new Crew();
        System.out.println(abrams.toString(0));
        System.out.println(abrams.toString(1));
        System.out.println(abrams.toString(2));
        System.out.println(abrams.toString(3));
        System.out.println(leopard.toString(4));
        System.out.println(leopard.toString(5));
        System.out.println(leopard.toString(6));
        System.out.println(leopard.toString(7));
        System.out.println(type10.toString(8));
        System.out.println(type10.toString(9));
        System.out.println(type10.toString(10));
        System.out.println(type10.toString(11));

    }
}
